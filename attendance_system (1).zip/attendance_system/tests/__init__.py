import logging

# Keep test output clean; services log warnings for destructive operations.
logging.disable(logging.CRITICAL)
