import sqlite3
import tempfile
import unittest
from pathlib import Path

from attendance import create_app
from attendance.database import SCHEMA_VERSION, Database
from attendance.exceptions import (
    ConflictError,
    DuplicateError,
    NotFoundError,
    ValidationError,
)

from .helpers import VALID_EMPLOYEE, AppTestCase


class EmployeeCrudTests(AppTestCase):
    def test_register_and_fetch_by_id_and_code(self):
        created = self.make_employee()
        self.assertEqual(created.employee_code, "EMP001")
        self.assertTrue(created.is_active)
        self.assertEqual(self.app.employees.get(created.id), created)
        self.assertEqual(self.app.employees.get("emp001"), created)  # case-insensitive code

    def test_duplicate_code_and_email_rejected(self):
        self.make_employee()
        with self.assertRaises(DuplicateError):
            self.make_employee(email="other@example.com")
        with self.assertRaises(DuplicateError):
            self.make_employee(employee_code="EMP002", email="ASHA.RAO@example.com")

    def test_invalid_data_is_not_persisted(self):
        with self.assertRaises(ValidationError):
            self.make_employee(email="bad")
        self.assertEqual(self.app.employees.list(), [])

    def test_get_unknown_raises(self):
        with self.assertRaises(NotFoundError):
            self.app.employees.get("EMP999")
        with self.assertRaises(NotFoundError):
            self.app.employees.get(999)

    def test_list_filters_search_and_pagination(self):
        self.make_employee()
        self.make_employee(employee_code="EMP002", first_name="Vikram", last_name="Singh",
                           email="v@example.com", department="Finance")
        self.make_employee(employee_code="EMP003", first_name="Meera", last_name="Nair",
                           email="m@example.com", department="Finance")
        svc = self.app.employees
        self.assertEqual(len(svc.list()), 3)
        self.assertEqual([e.employee_code for e in svc.list(department="finance")],
                         ["EMP002", "EMP003"])
        self.assertEqual([e.employee_code for e in svc.list(search="nair")], ["EMP003"])
        self.assertEqual([e.employee_code for e in svc.list(limit=1, offset=1)], ["EMP002"])
        self.assertEqual(svc.list(search="100%"), [])  # wildcard characters are escaped

    def test_update_changes_only_given_fields(self):
        emp = self.make_employee()
        updated = self.app.employees.update("EMP001", department="Finance", phone=None)
        self.assertEqual(updated.department, "Finance")
        self.assertEqual(updated.phone, emp.phone)
        self.assertGreaterEqual(updated.updated_at, emp.updated_at)

    def test_update_validation_and_duplicates(self):
        self.make_employee()
        self.make_employee(employee_code="EMP002", email="b@example.com")
        with self.assertRaises(ValidationError):
            self.app.employees.update("EMP001", email="bad")
        with self.assertRaises(ValidationError):
            self.app.employees.update("EMP001")  # nothing to change
        with self.assertRaises(DuplicateError):
            self.app.employees.update("EMP001", email="b@example.com")

    def test_deactivate_and_activate(self):
        self.make_employee()
        self.assertFalse(self.app.employees.deactivate("EMP001").is_active)
        with self.assertRaises(ConflictError):
            self.app.employees.deactivate("EMP001")
        self.assertTrue(self.app.employees.activate("EMP001").is_active)
        self.assertEqual(self.app.employees.list(status="inactive"), [])

    def test_delete_without_history(self):
        self.make_employee()
        self.assertEqual(self.app.employees.delete("EMP001"), 0)
        self.assertEqual(self.app.employees.list(), [])

    def test_delete_with_history_requires_force(self):
        self.make_employee()
        self.app.attendance.check_in("EMP001")
        with self.assertRaises(ConflictError):
            self.app.employees.delete("EMP001")
        self.assertEqual(len(self.app.employees.list()), 1)
        self.assertEqual(self.app.employees.delete("EMP001", force=True), 1)
        self.assertEqual(self.app.employees.list(), [])


class DatabaseTests(unittest.TestCase):
    def test_schema_version_and_constraints(self):
        with Database(":memory:") as db:
            self.assertEqual(db.schema_version, SCHEMA_VERSION)
            with self.assertRaises(sqlite3.IntegrityError):  # CHECK on status
                db.execute(
                    "INSERT INTO employees (employee_code, first_name, last_name, email, "
                    "department, designation, hire_date, status) "
                    "VALUES ('E1X','a','b','a@b.co','d','e','2020-01-01','retired')"
                )

    def test_foreign_keys_enforced(self):
        with Database(":memory:") as db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute(
                    "INSERT INTO attendance (employee_id, work_date, check_in, status) "
                    "VALUES (999, '2026-01-01', '2026-01-01 09:00:00', 'present')"
                )

    def test_transaction_rolls_back_on_error(self):
        with Database(":memory:") as db:
            with self.assertRaises(RuntimeError):
                with db.transaction():
                    db.execute(
                        "INSERT INTO employees (employee_code, first_name, last_name, email, "
                        "department, designation, hire_date) "
                        "VALUES ('E1X','a','b','a@b.co','d','e','2020-01-01')"
                    )
                    raise RuntimeError("boom")
            self.assertEqual(db.query_one("SELECT COUNT(*) AS n FROM employees")["n"], 0)

    def test_data_persists_across_connections(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "nested" / "attendance.db"
            first = create_app(path)
            first.employees.register(**VALID_EMPLOYEE)
            first.close()
            second = create_app(path)
            self.addCleanup(second.close)
            self.assertEqual(second.employees.get("EMP001").first_name, "Asha")


if __name__ == "__main__":
    unittest.main()
