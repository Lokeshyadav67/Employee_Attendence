import tempfile
import unittest
from datetime import datetime
from pathlib import Path

try:
    import flask  # noqa: F401
except ModuleNotFoundError:  # the core package works without Flask
    flask = None

from .helpers import VALID_EMPLOYEE, FakeClock

if flask:
    from attendance import create_app
    from attendance.web import create_web_app

EMPLOYEE_FORM = {k: v for k, v in VALID_EMPLOYEE.items()}


@unittest.skipUnless(flask, "Flask is not installed")
class WebTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.db = Path(tmp.name) / "web.db"
        self.clock = FakeClock(datetime(2026, 11, 12, 9, 0, 0))
        self.flask_app = create_web_app(self.db, secret_key="test", clock=self.clock, page_size=2)
        self.flask_app.testing = True
        self.client = self.flask_app.test_client()

    # -- helpers ------------------------------------------------------------------
    def token(self) -> str:
        self.client.get("/")  # renders a page, which creates the session token
        with self.client.session_transaction() as session:
            return session["_csrf"]

    def post(self, url, data=None, **kwargs):
        return self.client.post(url, data={**(data or {}), "_csrf": self.token()}, **kwargs)

    def add_employee(self, follow_redirects=False, **overrides):
        return self.post(
            "/employees/new", {**EMPLOYEE_FORM, **overrides}, follow_redirects=follow_redirects
        )

    def services(self):
        app = create_app(self.db, clock=self.clock)
        self.addCleanup(app.close)
        return app

    # -- pages render -----------------------------------------------------------------
    def test_all_pages_render_on_empty_database(self):
        for url in ("/", "/employees", "/employees/new", "/daily", "/monthly"):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_unknown_pages_return_404(self):
        self.assertEqual(self.client.get("/employees/999").status_code, 404)
        self.assertEqual(self.client.get("/records/999/edit").status_code, 404)
        self.assertEqual(self.client.get("/nope").status_code, 404)

    # -- security -----------------------------------------------------------------------
    def test_post_without_csrf_token_is_rejected(self):
        response = self.client.post("/employees/new", data=EMPLOYEE_FORM)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(self.services().employees.list(), [])

    def test_post_with_wrong_csrf_token_is_rejected(self):
        self.token()
        response = self.client.post("/employees/new", data={**EMPLOYEE_FORM, "_csrf": "wrong"})
        self.assertEqual(response.status_code, 400)

    def test_open_redirect_is_blocked(self):
        self.add_employee()
        response = self.post("/attendance/check-in", {"employee": "1", "next": "https://evil.example"})
        self.assertEqual(response.headers["Location"], "/")
        self.services().attendance.delete_record(1)
        response = self.post("/attendance/check-in", {"employee": "1", "next": "//evil.example"})
        self.assertEqual(response.headers["Location"], "/")

    def test_output_is_html_escaped(self):
        self.add_employee(first_name="Asha", last_name="Rao", department="<script>alert(1)</script>")
        page = self.client.get("/employees/1").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertIn("&lt;script&gt;", page)

    # -- employees ----------------------------------------------------------------------
    def test_add_employee_then_view(self):
        response = self.add_employee(follow_redirects=True)
        page = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("was added", page)
        self.assertIn("Asha Rao", page)

    def test_invalid_employee_shows_field_errors_and_keeps_input(self):
        response = self.add_employee(email="bad", hire_date="2099-01-01")
        page = response.get_data(as_text=True)
        self.assertIn("is not a valid email address", page)
        self.assertIn("cannot be in the future", page)
        self.assertIn('value="Asha"', page)  # what the user typed is preserved
        self.assertEqual(self.services().employees.list(), [])

    def test_duplicate_code_is_reported_on_the_form(self):
        self.add_employee()
        page = self.add_employee(email="other@example.com").get_data(as_text=True)
        self.assertIn("already exists", page)

    def test_edit_employee(self):
        self.add_employee()
        page = self.post(
            "/employees/1/edit", {**EMPLOYEE_FORM, "designation": "Principal Engineer"},
            follow_redirects=True,
        ).get_data(as_text=True)
        self.assertIn("was updated", page)
        self.assertIn("Principal Engineer", page)

    def test_search_filter_and_pagination(self):
        for i, name in enumerate(("Asha", "Bina", "Chitra"), start=1):
            self.add_employee(employee_code=f"EMP00{i}", first_name=name,
                              email=f"{name.lower()}@example.com")
        first = self.client.get("/employees").get_data(as_text=True)
        self.assertIn('href="/employees/1"', first)
        self.assertNotIn('href="/employees/3"', first)  # page size is 2
        self.assertIn("page=2", first)
        second = self.client.get("/employees?page=2").get_data(as_text=True)
        self.assertIn('href="/employees/3"', second)
        self.assertNotIn('href="/employees/1"', second)
        found = self.client.get("/employees?q=bina").get_data(as_text=True)
        self.assertIn('href="/employees/2"', found)
        self.assertNotIn('href="/employees/1"', found)

    def test_deactivate_and_reactivate(self):
        self.add_employee()
        page = self.post("/employees/1/status", {"status": "inactive"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("now inactive", page)
        self.assertFalse(self.services().employees.get(1).is_active)
        self.post("/employees/1/status", {"status": "active"})
        self.assertTrue(self.services().employees.get(1).is_active)

    def test_delete_requires_force_when_history_exists(self):
        self.add_employee()
        self.post("/attendance/check-in", {"employee": "1"})
        page = self.post("/employees/1/delete", follow_redirects=True).get_data(as_text=True)
        self.assertIn("attendance record", page)
        self.assertEqual(len(self.services().employees.list()), 1)
        self.post("/employees/1/delete", {"force": "on"})
        self.assertEqual(self.services().employees.list(), [])

    # -- attendance ---------------------------------------------------------------------------
    def test_check_in_and_check_out_from_dashboard(self):
        self.add_employee()
        page = self.post("/attendance/check-in", {"employee": "1"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("checked in at 09:00", page)
        self.clock.set("2026-11-12 17:30:00")
        page = self.post("/attendance/check-out", {"employee": "1"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("8.50 h", page)

    def test_business_rule_errors_are_shown_as_messages(self):
        self.add_employee()
        self.post("/attendance/check-in", {"employee": "1"})
        page = self.post("/attendance/check-in", {"employee": "1"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("already checked in", page)
        page = self.post("/attendance/check-in", {"employee": "99"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("not found", page)

    def test_backfill_time_from_detail_page(self):
        self.add_employee()
        self.post("/attendance/check-in", {"employee": "1", "at": "2026-11-11T09:40",
                                           "next": "/employees/1"})
        record = self.services().attendance.history("EMP001")[0]
        self.assertEqual((record.work_date.day, record.status), (11, "late"))

    def test_correct_and_delete_record(self):
        self.add_employee()
        self.post("/attendance/check-in", {"employee": "1"})
        self.clock.set("2026-11-12 17:00:00")
        self.post("/attendance/check-out", {"employee": "1"})

        form = self.client.get("/records/1/edit").get_data(as_text=True)
        self.assertIn('value="2026-11-12T09:00"', form)

        page = self.post("/records/1/edit", {"check_in": "2026-11-12T09:45",
                                             "check_out": "2026-11-12T17:00", "notes": "fixed"},
                         follow_redirects=True).get_data(as_text=True)
        self.assertIn("status recalculated", page)
        self.assertEqual(self.services().attendance.get_record(1).status, "late")

        bad = self.post("/records/1/edit", {"check_in": "2026-11-12T16:30",
                                            "check_out": "2026-11-12T16:00"}).get_data(as_text=True)
        self.assertIn("must be after check-in", bad)
        future = self.post("/records/1/edit", {"check_in": "2026-11-12T18:00"}).get_data(as_text=True)
        self.assertIn("cannot be in the future", future)

        self.post("/records/1/delete")
        self.assertEqual(self.services().attendance.history("EMP001"), [])

    # -- reports ----------------------------------------------------------------------------------
    def test_daily_and_monthly_reports(self):
        self.add_employee()
        self.add_employee(employee_code="EMP002", first_name="Vikram", last_name="Singh",
                          email="v@example.com")
        self.post("/attendance/check-in", {"employee": "1"})
        daily = self.client.get("/daily?date=2026-11-12").get_data(as_text=True)
        self.assertIn("Vikram Singh", daily)
        self.assertIn("badge-absent", daily)
        self.assertIn("badge-present", daily)
        monthly = self.client.get("/monthly?month=2026-11").get_data(as_text=True)
        self.assertIn("Asha Rao", monthly)
        one = self.client.get("/monthly?month=2026-11&employee=2").get_data(as_text=True)
        self.assertNotIn("Asha Rao</a>", one)

    def test_bad_report_parameters_fall_back_with_message(self):
        self.assertIn("YYYY-MM-DD", self.client.get("/daily?date=garbage").get_data(as_text=True))
        self.assertIn("YYYY-MM", self.client.get("/monthly?month=garbage").get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
