import unittest
from datetime import date, datetime

from attendance.exceptions import (
    ConflictError,
    DuplicateError,
    NotFoundError,
    ValidationError,
)

from .helpers import AppTestCase


class CheckInOutTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.emp = self.make_employee()
        self.att = self.app.attendance

    def test_on_time_check_in_and_full_day_check_out(self):
        record = self.att.check_in("EMP001")  # clock = 09:00
        self.assertEqual(record.status, "present")
        self.assertTrue(record.is_open)
        self.assertEqual(record.work_date, date(2026, 11, 12))

        self.clock.set("2026-11-12 17:30:00")
        record = self.att.check_out("EMP001")
        self.assertEqual(record.worked_hours, 8.5)
        self.assertEqual(record.status, "present")
        self.assertFalse(record.is_open)

    def test_grace_period_boundary(self):
        self.clock.set("2026-11-12 10:00:00")
        self.assertEqual(self.att.check_in("EMP001", at="09:15").status, "present")
        self.att.delete_record(1)
        self.assertEqual(self.att.check_in("EMP001", at="09:16").status, "late")

    def test_short_day_becomes_half_day(self):
        self.att.check_in("EMP001")
        self.clock.set("2026-11-12 12:00:00")
        self.assertEqual(self.att.check_out("EMP001").status, "half_day")

    def test_double_check_in_rejected(self):
        self.att.check_in("EMP001")
        with self.assertRaisesRegex(ConflictError, "already checked in"):
            self.att.check_in("EMP001")

    def test_second_check_in_same_day_after_check_out_rejected(self):
        self.att.check_in("EMP001")
        self.clock.set("2026-11-12 17:00:00")
        self.att.check_out("EMP001")
        with self.assertRaisesRegex(ConflictError, "already has attendance"):
            self.att.check_in("EMP001")

    def test_check_out_without_check_in_rejected(self):
        with self.assertRaisesRegex(ConflictError, "no open check-in"):
            self.att.check_out("EMP001")

    def test_forgotten_check_out_blocks_next_day(self):
        self.att.check_in("EMP001")
        self.clock.set("2026-11-13 09:00:00")
        with self.assertRaisesRegex(ConflictError, "no check-out for 2026-11-12"):
            self.att.check_in("EMP001")

    def test_inactive_employee_cannot_check_in(self):
        self.app.employees.deactivate("EMP001")
        with self.assertRaisesRegex(ConflictError, "inactive"):
            self.att.check_in("EMP001")

    def test_unknown_employee(self):
        with self.assertRaises(NotFoundError):
            self.att.check_in("EMP404")

    def test_future_time_rejected(self):
        with self.assertRaisesRegex(ValidationError, "future"):
            self.att.check_in("EMP001", at="2026-11-12 18:00")

    def test_check_out_before_check_in_rejected(self):
        self.att.check_in("EMP001")
        self.clock.set("2026-11-12 17:00:00")
        with self.assertRaises(ValidationError):
            self.att.check_out("EMP001", at="08:00")

    def test_overnight_shift_limit(self):
        self.att.check_in("EMP001")
        self.clock.set("2026-11-13 09:00:00")
        with self.assertRaisesRegex(ValidationError, "exceeds"):
            self.att.check_out("EMP001")

    def test_notes_are_cleaned_and_limited(self):
        record = self.att.check_in("EMP001", notes="  work   from home ")
        self.assertEqual(record.notes, "work from home")
        self.att.delete_record(record.id)
        with self.assertRaises(ValidationError):
            self.att.check_in("EMP001", notes="x" * 256)

    def test_invalid_time_format_rejected(self):
        with self.assertRaises(ValidationError):
            self.att.check_in("EMP001", at="noon")
        self.assertEqual(self.att.history("EMP001"), [])  # nothing was stored


class CorrectionTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.make_employee()
        self.att = self.app.attendance
        self.att.check_in("EMP001")
        self.clock.set("2026-11-12 17:00:00")
        self.record = self.att.check_out("EMP001")

    def test_correct_times_recomputes_status(self):
        fixed = self.att.correct_record(self.record.id, check_in="09:45")
        self.assertEqual(fixed.status, "late")
        self.assertEqual(fixed.worked_hours, 7.25)

    def test_correct_notes_only(self):
        fixed = self.att.correct_record(self.record.id, notes="approved by manager")
        self.assertEqual(fixed.notes, "approved by manager")
        self.assertEqual(fixed.check_in, self.record.check_in)

    def test_correct_rejects_invalid_span_and_missing_record(self):
        with self.assertRaises(ValidationError):
            self.att.correct_record(self.record.id, check_out="08:00")
        with self.assertRaises(ValidationError):
            self.att.correct_record(self.record.id)
        with self.assertRaises(NotFoundError):
            self.att.correct_record(999, notes="x")

    def test_moving_record_onto_existing_day_is_duplicate(self):
        self.clock.set("2026-11-13 09:00:00")
        other = self.att.check_in("EMP001")
        with self.assertRaises(DuplicateError):
            self.att.correct_record(other.id, check_in="2026-11-12 10:00")

    def test_delete_record(self):
        self.att.delete_record(self.record.id)
        self.assertEqual(self.att.history("EMP001"), [])
        with self.assertRaises(NotFoundError):
            self.att.delete_record(self.record.id)


class RetrievalTests(AppTestCase):
    def setUp(self):
        super().setUp()
        self.make_employee()
        self.make_employee(employee_code="EMP002", first_name="Vikram", last_name="Singh",
                           email="v@example.com", department="Finance")
        self.att = self.app.attendance
        # EMP001: Mon on time (8h), Tue late (8h), Wed half day (3h)
        for day, start, end in (("09", "09:00", "17:00"), ("10", "10:00", "18:00"),
                                ("11", "09:00", "12:00")):
            self.clock.set(f"2026-11-{day} {end}:00")
            self.att.check_in("EMP001", at=f"2026-11-{day} {start}")
            self.att.check_out("EMP001")
        self.clock.set("2026-11-12 09:00:00")

    def test_history_newest_first_with_range_and_pagination(self):
        history = self.att.history("EMP001")
        self.assertEqual([r.work_date.day for r in history], [11, 10, 9])
        self.assertEqual([r.work_date.day for r in self.att.history("EMP001", start="2026-11-10")],
                         [11, 10])
        self.assertEqual([r.work_date.day for r in
                          self.att.history("EMP001", end="2026-11-10", limit=1, offset=1)], [9])

    def test_history_rejects_inverted_range(self):
        with self.assertRaises(ValidationError):
            self.att.history("EMP001", start="2026-11-11", end="2026-11-01")

    def test_daily_report_lists_absent_employees(self):
        self.att.check_in("EMP002")  # today, 09:00
        report = {e.employee_code: e for e in self.att.daily_report()}
        self.assertEqual(report["EMP002"].status, "present")
        yesterday = {e.employee_code: e.status for e in self.att.daily_report("2026-11-11")}
        self.assertEqual(yesterday, {"EMP001": "half_day", "EMP002": "absent"})

    def test_daily_report_excludes_inactive_employees(self):
        self.app.employees.deactivate("EMP002")
        self.assertEqual([e.employee_code for e in self.att.daily_report()], ["EMP001"])

    def test_monthly_summary(self):
        self.att.check_in("EMP001")  # open record today
        summary = {s.employee_code: s for s in self.att.monthly_summary(2026, 11)}
        s = summary["EMP001"]
        self.assertEqual((s.days_worked, s.days_late, s.days_half_day, s.open_records),
                         (4, 1, 1, 1))
        self.assertEqual(s.total_hours, 19.0)
        self.assertEqual(summary["EMP002"].days_worked, 0)
        self.assertEqual(summary["EMP002"].total_hours, 0)

    def test_monthly_summary_single_employee_and_other_month(self):
        self.assertEqual(len(self.att.monthly_summary(2026, 11, "EMP001")), 1)
        self.assertEqual(self.att.monthly_summary(2026, 10, "EMP001")[0].days_worked, 0)
        with self.assertRaises(ValidationError):
            self.att.monthly_summary(2026, 13)


if __name__ == "__main__":
    unittest.main()
