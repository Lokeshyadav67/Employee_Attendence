import unittest
from datetime import date, datetime

from attendance.exceptions import ValidationError
from attendance.validators import (
    parse_date,
    parse_datetime,
    validate_employee,
    validate_pagination,
)

from .helpers import VALID_EMPLOYEE

TODAY = date(2026, 11, 12)


class EmployeeValidationTests(unittest.TestCase):
    def test_valid_data_is_normalised(self):
        data = {**VALID_EMPLOYEE, "employee_code": "emp001", "email": "  Asha.Rao@Example.COM ",
                "first_name": "  Asha   Maria "}
        cleaned = validate_employee(data, today=TODAY)
        self.assertEqual(cleaned["employee_code"], "EMP001")
        self.assertEqual(cleaned["email"], "asha.rao@example.com")
        self.assertEqual(cleaned["first_name"], "Asha Maria")
        self.assertEqual(cleaned["phone"], "+919800000001")
        self.assertEqual(cleaned["hire_date"], date(2023, 1, 16))

    def test_all_errors_are_reported_together(self):
        with self.assertRaises(ValidationError) as ctx:
            validate_employee(
                {"employee_code": "1", "first_name": "R2D2", "email": "nope"}, today=TODAY
            )
        errors = ctx.exception.errors
        for field in ("employee_code", "first_name", "email", "last_name",
                      "department", "designation", "hire_date"):
            self.assertIn(field, errors)

    def test_unknown_field_rejected(self):
        with self.assertRaises(ValidationError) as ctx:
            validate_employee({**VALID_EMPLOYEE, "salary": 1}, today=TODAY)
        self.assertIn("salary", ctx.exception.errors)

    def test_future_hire_date_rejected(self):
        with self.assertRaises(ValidationError) as ctx:
            validate_employee({**VALID_EMPLOYEE, "hire_date": "2026-11-13"}, today=TODAY)
        self.assertIn("hire_date", ctx.exception.errors)

    def test_bad_phone_rejected_but_blank_phone_allowed(self):
        with self.assertRaises(ValidationError):
            validate_employee({**VALID_EMPLOYEE, "phone": "12ab"}, today=TODAY)
        self.assertIsNone(validate_employee({**VALID_EMPLOYEE, "phone": ""}, today=TODAY)["phone"])

    def test_partial_validates_only_supplied_fields(self):
        self.assertEqual(
            validate_employee({"department": "Finance"}, partial=True, today=TODAY),
            {"department": "Finance"},
        )
        with self.assertRaises(ValidationError):
            validate_employee({"email": "bad"}, partial=True, today=TODAY)

    def test_non_string_values_rejected(self):
        with self.assertRaises(ValidationError):
            validate_employee({**VALID_EMPLOYEE, "first_name": 123}, today=TODAY)


class ParserTests(unittest.TestCase):
    def test_parse_date(self):
        self.assertEqual(parse_date("2026-11-12"), date(2026, 11, 12))
        with self.assertRaises(ValidationError):
            parse_date("12/11/2026")

    def test_parse_datetime_variants(self):
        expected = datetime(2026, 11, 12, 9, 30)
        self.assertEqual(parse_datetime("2026-11-12 09:30"), expected)
        self.assertEqual(parse_datetime("2026-11-12T09:30:00"), expected)
        self.assertEqual(parse_datetime("09:30", default_date=date(2026, 11, 12)), expected)

    def test_time_only_requires_default_date(self):
        with self.assertRaises(ValidationError):
            parse_datetime("09:30")

    def test_pagination_bounds(self):
        validate_pagination(10, 0)
        for limit, offset in ((0, 0), (501, 0), (10, -1)):
            with self.assertRaises(ValidationError):
                validate_pagination(limit, offset)


if __name__ == "__main__":
    unittest.main()
