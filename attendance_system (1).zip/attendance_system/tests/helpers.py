"""Shared test fixtures."""

import unittest
from datetime import datetime

from attendance import create_app


class FakeClock:
    def __init__(self, now: datetime):
        self.now = now

    def __call__(self) -> datetime:
        return self.now

    def set(self, value: str) -> None:
        self.now = datetime.fromisoformat(value)


VALID_EMPLOYEE = dict(
    employee_code="EMP001",
    first_name="Asha",
    last_name="Rao",
    email="asha.rao@example.com",
    phone="+91 98000 00001",
    department="Engineering",
    designation="Software Engineer",
    hire_date="2023-01-16",
)


class AppTestCase(unittest.TestCase):
    """Fresh in-memory database and a controllable clock for every test."""

    def setUp(self):
        self.clock = FakeClock(datetime(2026, 11, 12, 9, 0, 0))
        self.app = create_app(":memory:", clock=self.clock)
        self.addCleanup(self.app.close)

    def make_employee(self, **overrides):
        data = {**VALID_EMPLOYEE, **overrides}
        return self.app.employees.register(**data)
