# Employee Attendance Management System

A layered Python application for managing employees and their daily attendance, persisted in **SQLite**.
The backend and command-line tool use only the standard library. The **web interface** needs Flask
(`pip install -r requirements.txt`). Python 3.10+.

## Web interface

```bash
pip install -r requirements.txt        # once
python -m attendance seed              # optional sample employees
python -m attendance serve             # open http://127.0.0.1:5000
```

Options: `--port 8080`, `--host 0.0.0.0` (expose on your network), `--debug` (auto-reload, development only),
`--db path/to/file.db`.

| Page | What it does |
|------|--------------|
| Dashboard (`/`) | Today's status for every active employee with one-click **Check in / Check out**, plus live counts |
| Employees (`/employees`) | Search, filter by department/status, paginate; add, edit, deactivate, delete |
| Employee page | Details, check in/out with optional back-dated time, full history with date filter, edit/delete records |
| Daily report (`/daily`) | Pick any date; shows on-time, late, half-day and absent employees |
| Monthly summary (`/monthly`) | Days worked, late, half days, open check-ins and total hours, with totals row |

Web-layer design notes:

- Routes are thin: they parse the request, call the same **services** the CLI uses, then render or redirect, so business rules live in one place.
- **CSRF protection** on every POST, same-site-only redirects, auto-escaped templates, security headers.
- **One database connection per request** (SQLite connections must not be shared across threads).
- Set `SECRET_KEY` in the environment for sessions that survive restarts.
- The built-in Flask server is for development and small internal use. For production, run behind a WSGI server, e.g. `pip install waitress` then
  `waitress-serve --call attendance.web:create_web_app`.

## Features

- **Employee management** – register, look up (by id or code), search/filter/paginate, update, deactivate/reactivate, delete (protected when history exists)
- **Attendance tracking** – check-in / check-out with automatic status (`present`, `late`, `half_day`)
- **Record retrieval** – per-employee history (date range + pagination), daily report (includes absentees), monthly summary (days, late, half-days, open records, total hours)
- **Admin corrections** – fix times or notes of a record (status is recomputed), delete a record
- **Validation** – every input is normalised and validated; all field errors are reported at once
- **Data integrity** – constraints enforced in the database too (`UNIQUE`, `CHECK`, foreign keys), atomic transactions, versioned migrations

## Architecture

```
CLI (cli.py)  ·  Web (web/)       presentation only: parsing, forms, templates
   │
Services (services.py)            business rules, transactions, injectable clock
   │            │
Validators      Repositories      all SQL lives here; maps DB errors -> domain errors
(validators.py) (repositories.py)
                   │
              Database (database.py)   connection, PRAGMAs, transactions, migrations
                   │
               SQLite file
```

| File | Responsibility |
|------|----------------|
| `config.py` | DB path (`$ATTENDANCE_DB`), `AttendancePolicy` (shift start, grace, half-day threshold) |
| `models.py` | Immutable dataclasses: `Employee`, `AttendanceRecord`, `DailyEntry`, `MonthlySummary` |
| `exceptions.py` | `ValidationError`, `NotFoundError`, `DuplicateError`, `ConflictError`, `DatabaseError` |
| `bootstrap.py` | `create_app()` composition root (easy to reuse from a web API later) |

## Database design

```
employees                               attendance
─────────────────────────               ─────────────────────────────────────
id            PK                        id           PK
employee_code UNIQUE                    employee_id  FK -> employees.id (RESTRICT)
first_name, last_name                   work_date    ┐ UNIQUE(employee_id, work_date)
email         UNIQUE (nocase)           check_in
phone         nullable                  check_out    nullable (NULL = still checked in)
department, designation                 status       present | late | half_day
hire_date                               notes
status        active | inactive         created_at, updated_at
created_at, updated_at                  CHECK (check_out IS NULL OR check_out > check_in)
```

Design decisions:

- **One record per employee per day**, enforced by a composite `UNIQUE` constraint, so double check-ins are impossible even under concurrent writers.
- **`ON DELETE RESTRICT`** protects history. The normal way to retire someone is `deactivate`; `delete --force` is an explicit opt-in.
- **`absent` is derived**, never stored: a daily report left-joins active employees to their record.
- **Timestamps are ISO-8601 text** (`YYYY-MM-DD HH:MM:SS`), which sorts correctly and works with SQLite date functions.
- **Indexes** on `work_date`, `department`, `status`; the unique constraint covers `(employee_id, work_date)` lookups.
- **Triggers** maintain `updated_at`. **`PRAGMA user_version`** tracks schema migrations (`MIGRATIONS` in `database.py`).
- Connections use **foreign keys ON**, **WAL** (file DBs) and **parameterised queries only**.

## Attendance rules

| Rule | Behaviour |
|------|-----------|
| On time | Check-in at or before `shift_start + grace` (default 09:00 + 15 min) |
| Late | Check-in after the cut-off |
| Half day | Worked less than 4 h at check-out (takes precedence over `late`) |
| Double check-in | Rejected; one record per day |
| Forgotten check-out | Blocks the next check-in until corrected with `attendance correct` |
| Future times | Rejected |
| Shift length | Check-out must be after check-in and within 16 h |
| Inactive employee | Cannot check in |

Change the thresholds by passing an `AttendancePolicy` to `create_app()`.

## Command-line quick start

```bash
cd attendance_system
python -m attendance seed                      # optional sample data
python -m attendance employee list
```

The database defaults to `data/attendance.db`; override with `--db PATH` or `ATTENDANCE_DB`.

### Employees

```bash
python -m attendance employee add --code EMP010 --first-name Neha --last-name Gupta \
    --email neha@example.com --department Finance --designation Analyst --hire-date 2024-02-01
python -m attendance employee list --department Finance --search neha --limit 20
python -m attendance employee show EMP010
python -m attendance employee update EMP010 --designation "Senior Analyst"
python -m attendance employee deactivate EMP010
python -m attendance employee delete EMP010 --force
```

### Attendance

```bash
python -m attendance attendance check-in EMP001                     # now
python -m attendance attendance check-out EMP001 --at 17:30
python -m attendance attendance check-in EMP002 --at "2026-11-10 09:05" --notes "client visit"
python -m attendance attendance history EMP001 --from 2026-11-01 --to 2026-11-30
python -m attendance attendance daily --date 2026-11-11
python -m attendance attendance summary --month 2026-11 [--employee EMP001]
python -m attendance attendance correct 12 --check-out 18:00
python -m attendance attendance delete 12
```

Exit codes: `0` success, `1` application error (message on stderr), `2` bad command-line usage.

## Using it as a library

```python
from attendance import create_app

app = create_app("attendance.db")
emp = app.employees.register(
    employee_code="EMP100", first_name="Asha", last_name="Rao",
    email="asha@example.com", department="Engineering",
    designation="Engineer", hire_date="2023-01-16",
)
app.attendance.check_in("EMP100")
app.attendance.check_out("EMP100")
for record in app.attendance.history("EMP100", limit=10):
    print(record.work_date, record.status, record.worked_hours)
app.close()
```

## Tests

```bash
python -m unittest discover -s tests -t . -v
```

69 tests cover validation, CRUD, constraints, transactions/rollback, persistence, check-in/out rules,
status calculation boundaries, corrections, history pagination, daily and monthly reports, and the web
layer (page rendering, CSRF, redirect safety, HTML escaping, form errors, full check-in/out flows).
The services take an injectable clock, so time-dependent logic is tested deterministically.
Web tests are skipped automatically if Flask is not installed.

## Extending

- **REST/JSON API**: add routes to the Flask app that call the same services; they already raise typed errors that map cleanly to HTTP 400/404/409.
- **Authentication / roles**: add a `users` migration and guard `correct_record` / `delete` as admin-only.
- **Multiple shifts, leave, holidays**: add tables in a new migration (`MIGRATIONS[2]`).
- **PostgreSQL/MySQL**: only `database.py` and the SQL in `repositories.py` need to change.
