"""SQLite connection management, transactions and schema migrations."""

from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Optional, Sequence, Union

from .exceptions import DatabaseError

logger = logging.getLogger(__name__)

_NOW = "strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime')"

# Migrations are applied in order; ``PRAGMA user_version`` records progress.
MIGRATIONS = {
    1: f"""
    CREATE TABLE employees (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_code TEXT NOT NULL UNIQUE
                      CHECK (length(employee_code) BETWEEN 3 AND 20),
        first_name    TEXT NOT NULL CHECK (length(trim(first_name)) > 0),
        last_name     TEXT NOT NULL CHECK (length(trim(last_name)) > 0),
        email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
        phone         TEXT,
        department    TEXT NOT NULL CHECK (length(trim(department)) > 0),
        designation   TEXT NOT NULL CHECK (length(trim(designation)) > 0),
        hire_date     TEXT NOT NULL,
        status        TEXT NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active', 'inactive')),
        created_at    TEXT NOT NULL DEFAULT ({_NOW}),
        updated_at    TEXT NOT NULL DEFAULT ({_NOW})
    );

    CREATE INDEX idx_employees_department ON employees (department);
    CREATE INDEX idx_employees_status     ON employees (status);

    CREATE TABLE attendance (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL
                    REFERENCES employees (id) ON DELETE RESTRICT,
        work_date   TEXT NOT NULL,
        check_in    TEXT NOT NULL,
        check_out   TEXT,
        status      TEXT NOT NULL
                    CHECK (status IN ('present', 'late', 'half_day')),
        notes       TEXT,
        created_at  TEXT NOT NULL DEFAULT ({_NOW}),
        updated_at  TEXT NOT NULL DEFAULT ({_NOW}),
        CHECK (check_out IS NULL OR check_out > check_in),
        UNIQUE (employee_id, work_date)
    );

    CREATE INDEX idx_attendance_work_date ON attendance (work_date);

    CREATE TRIGGER trg_employees_updated_at
    AFTER UPDATE ON employees
    FOR EACH ROW WHEN NEW.updated_at = OLD.updated_at
    BEGIN
        UPDATE employees SET updated_at = {_NOW} WHERE id = NEW.id;
    END;

    CREATE TRIGGER trg_attendance_updated_at
    AFTER UPDATE ON attendance
    FOR EACH ROW WHEN NEW.updated_at = OLD.updated_at
    BEGIN
        UPDATE attendance SET updated_at = {_NOW} WHERE id = NEW.id;
    END;
    """,
}

SCHEMA_VERSION = max(MIGRATIONS)


class Database:
    """Thin wrapper around a single SQLite connection.

    * Foreign keys are enforced and WAL is enabled for file databases.
    * Autocommit mode is used; multi-statement work goes through
      :meth:`transaction`, which supports nesting.
    * All values are passed as bound parameters (no string interpolation).
    """

    def __init__(self, path: Union[str, Path] = ":memory:"):
        self.path = str(path)
        self._depth = 0
        if self.path != ":memory:":
            Path(self.path).expanduser().parent.mkdir(parents=True, exist_ok=True)
        try:
            self._conn = sqlite3.connect(
                self.path, isolation_level=None, timeout=10.0
            )
        except sqlite3.Error as exc:
            raise DatabaseError(f"Cannot open database '{self.path}': {exc}") from exc
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        if self.path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")
        self._migrate()

    # -- lifecycle ---------------------------------------------------------
    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "Database":
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.close()

    # -- migrations --------------------------------------------------------
    @property
    def schema_version(self) -> int:
        return self._conn.execute("PRAGMA user_version").fetchone()[0]

    def _migrate(self) -> None:
        current = self.schema_version
        for version in sorted(MIGRATIONS):
            if version <= current:
                continue
            logger.info("Applying migration %s", version)
            script = (
                f"BEGIN;\n{MIGRATIONS[version]}\n"
                f"PRAGMA user_version = {int(version)};\nCOMMIT;"
            )
            try:
                self._conn.executescript(script)
            except sqlite3.Error as exc:
                if self._conn.in_transaction:
                    self._conn.execute("ROLLBACK")
                raise DatabaseError(f"Migration {version} failed: {exc}") from exc

    # -- transactions ------------------------------------------------------
    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Run a block atomically. Nested use joins the outer transaction."""
        if self._depth > 0:
            self._depth += 1
            try:
                yield self._conn
            finally:
                self._depth -= 1
            return

        self._conn.execute("BEGIN IMMEDIATE")
        self._depth = 1
        try:
            yield self._conn
            self._conn.execute("COMMIT")
        except BaseException:
            if self._conn.in_transaction:
                self._conn.execute("ROLLBACK")
            raise
        finally:
            self._depth = 0

    # -- query helpers -----------------------------------------------------
    def execute(self, sql: str, params: Sequence[Any] = ()) -> sqlite3.Cursor:
        try:
            return self._conn.execute(sql, params)
        except sqlite3.IntegrityError:
            raise  # repositories translate these into domain errors
        except sqlite3.Error as exc:
            logger.exception("Database error")
            raise DatabaseError(str(exc)) from exc

    def query_one(self, sql: str, params: Sequence[Any] = ()) -> Optional[sqlite3.Row]:
        return self.execute(sql, params).fetchone()

    def query_all(self, sql: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        return self.execute(sql, params).fetchall()
