"""Application configuration and attendance policy."""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import time
from pathlib import Path

DB_ENV_VAR = "ATTENDANCE_DB"


def default_db_path() -> Path:
    """Database location: ``$ATTENDANCE_DB`` or ``./data/attendance.db``."""
    return Path(os.environ.get(DB_ENV_VAR, "data/attendance.db"))


@dataclass(frozen=True)
class AttendancePolicy:
    """Business rules that drive status calculation.

    shift_start      -- official start of the working day
    grace_minutes    -- minutes after shift_start still counted as on time
    half_day_hours   -- worked hours below this value make the day a half day
    max_shift_hours  -- sanity limit for a single check-in/check-out pair
    """

    shift_start: time = time(9, 0)
    grace_minutes: int = 15
    half_day_hours: float = 4.0
    max_shift_hours: float = 16.0
