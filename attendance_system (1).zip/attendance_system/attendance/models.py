"""Immutable domain models mapped from database rows."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional

EMPLOYEE_ACTIVE = "active"
EMPLOYEE_INACTIVE = "inactive"

STATUS_PRESENT = "present"
STATUS_LATE = "late"
STATUS_HALF_DAY = "half_day"
STATUS_ABSENT = "absent"  # derived in reports; never stored


@dataclass(frozen=True)
class Employee:
    id: int
    employee_code: str
    first_name: str
    last_name: str
    email: str
    phone: Optional[str]
    department: str
    designation: str
    hire_date: date
    status: str
    created_at: datetime
    updated_at: datetime

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    @property
    def is_active(self) -> bool:
        return self.status == EMPLOYEE_ACTIVE

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "Employee":
        return cls(
            id=row["id"],
            employee_code=row["employee_code"],
            first_name=row["first_name"],
            last_name=row["last_name"],
            email=row["email"],
            phone=row["phone"],
            department=row["department"],
            designation=row["designation"],
            hire_date=date.fromisoformat(row["hire_date"]),
            status=row["status"],
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )


@dataclass(frozen=True)
class AttendanceRecord:
    id: int
    employee_id: int
    work_date: date
    check_in: datetime
    check_out: Optional[datetime]
    status: str
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime

    @property
    def is_open(self) -> bool:
        return self.check_out is None

    @property
    def worked_hours(self) -> Optional[float]:
        if self.check_out is None:
            return None
        return round((self.check_out - self.check_in).total_seconds() / 3600, 2)

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "AttendanceRecord":
        check_out = row["check_out"]
        return cls(
            id=row["id"],
            employee_id=row["employee_id"],
            work_date=date.fromisoformat(row["work_date"]),
            check_in=datetime.fromisoformat(row["check_in"]),
            check_out=datetime.fromisoformat(check_out) if check_out else None,
            status=row["status"],
            notes=row["notes"],
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )


@dataclass(frozen=True)
class DailyEntry:
    """One employee's attendance for a given day (``absent`` if no record)."""

    employee_id: int
    employee_code: str
    full_name: str
    department: str
    status: str
    check_in: Optional[datetime]
    check_out: Optional[datetime]

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "DailyEntry":
        check_in, check_out = row["check_in"], row["check_out"]
        return cls(
            employee_id=row["employee_id"],
            employee_code=row["employee_code"],
            full_name=row["full_name"],
            department=row["department"],
            status=row["status"] or STATUS_ABSENT,
            check_in=datetime.fromisoformat(check_in) if check_in else None,
            check_out=datetime.fromisoformat(check_out) if check_out else None,
        )


@dataclass(frozen=True)
class MonthlySummary:
    employee_id: int
    employee_code: str
    full_name: str
    department: str
    days_worked: int
    days_late: int
    days_half_day: int
    open_records: int
    total_hours: float

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "MonthlySummary":
        return cls(
            employee_id=row["id"],
            employee_code=row["employee_code"],
            full_name=row["full_name"],
            department=row["department"],
            days_worked=row["days_worked"],
            days_late=row["days_late"],
            days_half_day=row["days_half_day"],
            open_records=row["open_records"],
            total_hours=round(row["total_hours"], 2),
        )
