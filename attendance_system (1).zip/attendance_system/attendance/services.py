"""Business-logic layer.

Services enforce rules (who can check in, how status is derived, what may be
deleted) and coordinate repositories inside transactions. They accept an
injectable ``clock`` so time-dependent behaviour is deterministic in tests.
"""

from __future__ import annotations

import calendar
import logging
from datetime import date, datetime, timedelta
from typing import Any, Callable, Optional, Union

from .config import AttendancePolicy
from .database import Database
from .exceptions import ConflictError, NotFoundError, ValidationError
from .models import (
    EMPLOYEE_ACTIVE,
    EMPLOYEE_INACTIVE,
    STATUS_HALF_DAY,
    STATUS_LATE,
    STATUS_PRESENT,
    AttendanceRecord,
    DailyEntry,
    Employee,
    MonthlySummary,
)
from .repositories import AttendanceRepository, EmployeeRepository
from .validators import (
    parse_date,
    parse_datetime,
    validate_employee,
    validate_month,
    validate_pagination,
)

logger = logging.getLogger(__name__)

Clock = Callable[[], datetime]
EmployeeRef = Union[int, str]  # numeric id or employee code


def _now(clock: Clock) -> datetime:
    return clock().replace(microsecond=0)


class EmployeeService:
    def __init__(
        self,
        db: Database,
        employees: EmployeeRepository,
        attendance: AttendanceRepository,
        clock: Clock = datetime.now,
    ):
        self._db = db
        self._employees = employees
        self._attendance = attendance
        self._clock = clock

    # -- create / read ---------------------------------------------------------
    def register(self, **data: Any) -> Employee:
        cleaned = validate_employee(data, today=self._clock().date())
        employee = self._employees.add(cleaned)
        logger.info("Registered employee %s (id=%s)", employee.employee_code, employee.id)
        return employee

    def get(self, ref: EmployeeRef) -> Employee:
        """Look an employee up by numeric id or by employee code."""
        text = str(ref).strip()
        employee = (
            self._employees.get(int(text))
            if text.isdigit()
            else self._employees.get_by_code(text.upper())
        )
        if employee is None:
            raise NotFoundError(f"Employee '{ref}' not found")
        return employee

    def list(
        self,
        *,
        status: Optional[str] = None,
        department: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Employee]:
        validate_pagination(limit, offset)
        if status not in (None, EMPLOYEE_ACTIVE, EMPLOYEE_INACTIVE):
            raise ValidationError("status: must be 'active' or 'inactive'", {"status": "invalid"})
        return self._employees.list(
            status=status, department=department, search=search, limit=limit, offset=offset
        )

    def departments(self) -> list[str]:
        return self._employees.departments()

    # -- update ------------------------------------------------------------------
    def update(self, ref: EmployeeRef, **changes: Any) -> Employee:
        changes = {k: v for k, v in changes.items() if v is not None}
        if not changes:
            raise ValidationError("No changes supplied")
        employee = self.get(ref)
        cleaned = validate_employee(changes, partial=True, today=self._clock().date())
        updated = self._employees.update(employee.id, cleaned)
        logger.info("Updated employee %s: %s", updated.employee_code, sorted(cleaned))
        return updated

    def deactivate(self, ref: EmployeeRef) -> Employee:
        return self._set_status(ref, EMPLOYEE_INACTIVE)

    def activate(self, ref: EmployeeRef) -> Employee:
        return self._set_status(ref, EMPLOYEE_ACTIVE)

    def _set_status(self, ref: EmployeeRef, status: str) -> Employee:
        employee = self.get(ref)
        if employee.status == status:
            raise ConflictError(f"{employee.full_name} is already {status}")
        updated = self._employees.update(employee.id, {"status": status})
        logger.info("Employee %s is now %s", updated.employee_code, status)
        return updated

    # -- delete ------------------------------------------------------------------
    def delete(self, ref: EmployeeRef, *, force: bool = False) -> int:
        """Delete an employee. Returns the number of attendance records removed.

        Employees with history are protected unless ``force`` is set; the
        normal way to retire someone is :meth:`deactivate`.
        """
        employee = self.get(ref)
        with self._db.transaction():
            count = self._attendance.count_for_employee(employee.id)
            if count and not force:
                raise ConflictError(
                    f"{employee.full_name} has {count} attendance record(s). "
                    "Deactivate the employee instead, or delete with force."
                )
            if count:
                self._attendance.delete_for_employee(employee.id)
            self._employees.delete(employee.id)
        logger.warning("Deleted employee %s and %s attendance record(s)", employee.employee_code, count)
        return count


class AttendanceService:
    def __init__(
        self,
        db: Database,
        employees: EmployeeService,
        attendance: AttendanceRepository,
        policy: AttendancePolicy = AttendancePolicy(),
        clock: Clock = datetime.now,
    ):
        self._db = db
        self._employees = employees
        self._attendance = attendance
        self._policy = policy
        self._clock = clock

    # -- check-in / check-out ----------------------------------------------------
    def check_in(
        self,
        ref: EmployeeRef,
        at: Union[None, str, datetime] = None,
        notes: Optional[str] = None,
    ) -> AttendanceRecord:
        employee = self._employees.get(ref)
        if not employee.is_active:
            raise ConflictError(f"{employee.full_name} is inactive and cannot check in")

        now = _now(self._clock)
        moment = self._resolve_moment(at, now, "at")
        notes = self._clean_notes(notes)

        with self._db.transaction():
            open_record = self._attendance.get_open_record(employee.id)
            if open_record:
                if open_record.work_date == moment.date():
                    raise ConflictError(
                        f"{employee.full_name} already checked in today at "
                        f"{open_record.check_in:%H:%M}"
                    )
                raise ConflictError(
                    f"{employee.full_name} has no check-out for {open_record.work_date}. "
                    f"Close record {open_record.id} first (attendance correct {open_record.id} --check-out ...)."
                )
            if self._attendance.get_for_day(employee.id, moment.date()):
                raise ConflictError(
                    f"{employee.full_name} already has attendance for {moment.date()}"
                )
            record = self._attendance.create(
                employee.id,
                moment.date(),
                moment,
                self._compute_status(moment, None),
                notes,
            )
        logger.info("Check-in: %s at %s (%s)", employee.employee_code, moment, record.status)
        return record

    def check_out(
        self, ref: EmployeeRef, at: Union[None, str, datetime] = None
    ) -> AttendanceRecord:
        employee = self._employees.get(ref)
        now = _now(self._clock)
        moment = self._resolve_moment(at, now, "at")

        with self._db.transaction():
            open_record = self._attendance.get_open_record(employee.id)
            if open_record is None:
                raise ConflictError(f"{employee.full_name} has no open check-in")
            self._validate_span(open_record.check_in, moment)
            record = self._attendance.set_times(
                open_record.id,
                work_date=open_record.work_date,
                check_in=open_record.check_in,
                check_out=moment,
                status=self._compute_status(open_record.check_in, moment),
                notes=open_record.notes,
            )
        logger.info(
            "Check-out: %s at %s (%.2f h, %s)",
            employee.employee_code, moment, record.worked_hours, record.status,
        )
        return record

    # -- corrections (admin) -------------------------------------------------------
    def correct_record(
        self,
        record_id: int,
        *,
        check_in: Union[None, str, datetime] = None,
        check_out: Union[None, str, datetime] = None,
        notes: Optional[str] = None,
    ) -> AttendanceRecord:
        if check_in is None and check_out is None and notes is None:
            raise ValidationError("No changes supplied")
        now = _now(self._clock)

        with self._db.transaction():
            existing = self._get_record(record_id)
            new_in = (
                self._resolve_moment(check_in, now, "check_in", existing.work_date)
                if check_in is not None
                else existing.check_in
            )
            new_out = (
                self._resolve_moment(check_out, now, "check_out", new_in.date())
                if check_out is not None
                else existing.check_out
            )
            if new_out is not None:
                self._validate_span(new_in, new_out)
            new_notes = self._clean_notes(notes) if notes is not None else existing.notes
            record = self._attendance.set_times(
                record_id,
                work_date=new_in.date(),
                check_in=new_in,
                check_out=new_out,
                status=self._compute_status(new_in, new_out),
                notes=new_notes,
            )
        logger.info("Corrected attendance record %s", record_id)
        return record

    def get_record(self, record_id: int) -> AttendanceRecord:
        return self._get_record(record_id)

    def delete_record(self, record_id: int) -> None:
        self._get_record(record_id)
        self._attendance.delete(record_id)
        logger.warning("Deleted attendance record %s", record_id)

    # -- retrieval -----------------------------------------------------------------
    def history(
        self,
        ref: EmployeeRef,
        *,
        start: Union[None, str, date] = None,
        end: Union[None, str, date] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AttendanceRecord]:
        validate_pagination(limit, offset)
        employee = self._employees.get(ref)
        start_date = parse_date(start, "from") if start is not None else None
        end_date = parse_date(end, "to") if end is not None else None
        if start_date and end_date and start_date > end_date:
            raise ValidationError("from: must not be after 'to'", {"from": "after 'to'"})
        return self._attendance.list(
            employee_id=employee.id, start=start_date, end=end_date, limit=limit, offset=offset
        )

    def daily_report(self, day: Union[None, str, date] = None) -> list[DailyEntry]:
        work_date = parse_date(day, "date") if day is not None else self._clock().date()
        return self._attendance.daily_report(work_date)

    def monthly_summary(
        self, year: int, month: int, ref: Optional[EmployeeRef] = None
    ) -> list[MonthlySummary]:
        validate_month(year, month)
        start = date(year, month, 1)
        end = date(year, month, calendar.monthrange(year, month)[1])
        employee_id = self._employees.get(ref).id if ref is not None else None
        return self._attendance.monthly_summary(start, end, employee_id)

    # -- internals -------------------------------------------------------------------
    def _compute_status(self, check_in: datetime, check_out: Optional[datetime]) -> str:
        if check_out is not None:
            hours = (check_out - check_in).total_seconds() / 3600
            if hours < self._policy.half_day_hours:
                return STATUS_HALF_DAY
        cutoff = datetime.combine(check_in.date(), self._policy.shift_start) + timedelta(
            minutes=self._policy.grace_minutes
        )
        return STATUS_LATE if check_in > cutoff else STATUS_PRESENT

    def _validate_span(self, check_in: datetime, check_out: datetime) -> None:
        if check_out <= check_in:
            raise ValidationError(
                "check_out: must be after check-in "
                f"({check_in:%Y-%m-%d %H:%M})",
                {"check_out": "must be after check-in"},
            )
        hours = (check_out - check_in).total_seconds() / 3600
        if hours > self._policy.max_shift_hours:
            raise ValidationError(
                f"check_out: shift of {hours:.1f} h exceeds the {self._policy.max_shift_hours:g} h limit",
                {"check_out": "shift too long"},
            )

    def _resolve_moment(
        self,
        value: Union[None, str, datetime],
        now: datetime,
        field: str,
        default_date: Optional[date] = None,
    ) -> datetime:
        if value is None:
            return now
        moment = parse_datetime(value, field, default_date=default_date or now.date())
        if moment > now:
            raise ValidationError(
                f"{field}: cannot be in the future", {field: "cannot be in the future"}
            )
        return moment

    @staticmethod
    def _clean_notes(notes: Optional[str]) -> Optional[str]:
        if notes is None:
            return None
        text = " ".join(str(notes).split())
        if len(text) > 255:
            raise ValidationError("notes: must be at most 255 characters", {"notes": "too long"})
        return text or None

    def _get_record(self, record_id: int) -> AttendanceRecord:
        record = self._attendance.get(record_id)
        if record is None:
            raise NotFoundError(f"Attendance record {record_id} not found")
        return record
