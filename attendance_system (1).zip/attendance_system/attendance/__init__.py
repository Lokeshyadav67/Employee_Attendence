"""Employee Attendance Management System (SQLite backend)."""

from .bootstrap import App, create_app
from .exceptions import (
    AttendanceError,
    ConflictError,
    DatabaseError,
    DuplicateError,
    NotFoundError,
    ValidationError,
)

__all__ = [
    "App",
    "create_app",
    "AttendanceError",
    "ConflictError",
    "DatabaseError",
    "DuplicateError",
    "NotFoundError",
    "ValidationError",
]

__version__ = "1.0.0"
