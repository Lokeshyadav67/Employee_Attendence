"""Domain exceptions.

Every error the application raises on purpose derives from ``AttendanceError``
so callers (CLI, a future REST layer, ...) can handle them in one place.
"""

from __future__ import annotations

from typing import Mapping, Optional


class AttendanceError(Exception):
    """Base class for all application errors."""


class ValidationError(AttendanceError):
    """Input failed validation. ``errors`` maps field name -> message."""

    def __init__(self, message: str, errors: Optional[Mapping[str, str]] = None):
        super().__init__(message)
        self.errors = dict(errors or {})

    @classmethod
    def from_errors(cls, errors: Mapping[str, str]) -> "ValidationError":
        message = "; ".join(f"{field}: {msg}" for field, msg in errors.items())
        return cls(message, errors)


class NotFoundError(AttendanceError):
    """A requested record does not exist."""


class DuplicateError(AttendanceError):
    """A uniqueness constraint was violated (code, email, daily record)."""


class ConflictError(AttendanceError):
    """The operation conflicts with the current state (business rule)."""


class DatabaseError(AttendanceError):
    """Unexpected database failure."""
