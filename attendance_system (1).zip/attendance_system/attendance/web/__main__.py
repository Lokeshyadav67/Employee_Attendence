"""Run the web server:  python -m attendance.web [--port 5000]"""

import argparse

from .app import create_web_app


def main() -> None:
    parser = argparse.ArgumentParser(prog="attendance.web", description="Attendance web UI")
    parser.add_argument("--db", help="database file (default: $ATTENDANCE_DB or data/attendance.db)")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--debug", action="store_true", help="auto-reload and debugger (development only)")
    args = parser.parse_args()
    app = create_web_app(args.db)
    print(f"Attendance web UI running at http://{args.host}:{args.port}  (Ctrl+C to stop)")
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
