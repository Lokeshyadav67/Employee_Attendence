"""Routes. Thin: parse the request, call a service, render or redirect."""

from __future__ import annotations

import re
from collections import Counter
from datetime import date

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from ..exceptions import AttendanceError, ValidationError
from .app import get_services

bp = Blueprint("views", __name__)

EMPLOYEE_FIELDS = (
    "employee_code", "first_name", "last_name", "email",
    "phone", "department", "designation", "hire_date",
)


# -- helpers -----------------------------------------------------------------------
def _today() -> date:
    return current_app.config["CLOCK"]().date()


def _page() -> int:
    return max(request.args.get("page", 1, type=int) or 1, 1)


def _safe_next(default: str) -> str:
    """Only follow same-site relative redirects (prevents open redirects)."""
    target = request.form.get("next") or request.args.get("next") or ""
    if target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return default


def _field_errors(exc: AttendanceError) -> dict[str, str]:
    """Attach duplicate-value errors to the form field they belong to."""
    if isinstance(exc, ValidationError):
        return exc.errors
    message = str(exc)
    if "code" in message:
        return {"employee_code": message}
    if "email" in message:
        return {"email": message}
    return {}


# -- dashboard & attendance actions -------------------------------------------------
@bp.get("/")
def dashboard():
    entries = get_services().attendance.daily_report()
    counts = Counter(e.status for e in entries)
    checked_in = sum(1 for e in entries if e.check_in)
    still_in = sum(1 for e in entries if e.check_in and not e.check_out)
    return render_template(
        "dashboard.html", entries=entries, counts=counts,
        checked_in=checked_in, still_in=still_in, today=_today(),
    )


@bp.post("/attendance/check-in")
def check_in():
    services = get_services()
    ref = request.form.get("employee", "")
    try:
        employee = services.employees.get(ref)
        record = services.attendance.check_in(
            ref, at=request.form.get("at") or None, notes=request.form.get("notes") or None
        )
        flash(
            f"{employee.full_name} checked in at {record.check_in:%H:%M} "
            f"({record.status.replace('_', ' ')}).", "success",
        )
    except AttendanceError as exc:
        flash(str(exc), "error")
    return redirect(_safe_next(url_for("views.dashboard")))


@bp.post("/attendance/check-out")
def check_out():
    services = get_services()
    ref = request.form.get("employee", "")
    try:
        employee = services.employees.get(ref)
        record = services.attendance.check_out(ref, at=request.form.get("at") or None)
        flash(
            f"{employee.full_name} checked out at {record.check_out:%H:%M} — "
            f"{record.worked_hours:.2f} h ({record.status.replace('_', ' ')}).", "success",
        )
    except AttendanceError as exc:
        flash(str(exc), "error")
    return redirect(_safe_next(url_for("views.dashboard")))


# -- employees ------------------------------------------------------------------------
@bp.get("/employees")
def employees():
    services = get_services()
    q = request.args.get("q", "").strip()
    status = request.args.get("status") or None
    department = request.args.get("department") or None
    page, size = _page(), current_app.config["PAGE_SIZE"]
    try:
        rows = services.employees.list(
            status=status, department=department, search=q or None,
            limit=size + 1, offset=(page - 1) * size,
        )
    except ValidationError as exc:
        flash(str(exc), "error")
        rows = []
    filters = {k: v for k, v in (("q", q), ("status", status), ("department", department)) if v}
    return render_template(
        "employees.html", employees=rows[:size], has_next=len(rows) > size, page=page,
        filters=filters, q=q, status=status or "", department=department or "",
        departments=services.employees.departments(),
    )


@bp.route("/employees/new", methods=["GET", "POST"])
def employee_new():
    services = get_services()
    form: dict[str, str] = {}
    errors: dict[str, str] = {}
    if request.method == "POST":
        form = {f: request.form.get(f, "").strip() for f in EMPLOYEE_FIELDS}
        try:
            employee = services.employees.register(**form)
            flash(f"{employee.full_name} ({employee.employee_code}) was added.", "success")
            return redirect(url_for("views.employee_detail", employee_id=employee.id))
        except AttendanceError as exc:
            errors = _field_errors(exc)
            flash(
                "Please correct the highlighted fields." if errors else str(exc), "error"
            )
    return render_template(
        "employee_form.html", employee=None, form=form, errors=errors,
        departments=services.employees.departments(),
    )


@bp.get("/employees/<int:employee_id>")
def employee_detail(employee_id: int):
    services = get_services()
    employee = services.employees.get(employee_id)
    start = request.args.get("from") or None
    end = request.args.get("to") or None
    page, size = _page(), current_app.config["PAGE_SIZE"]
    try:
        records = services.attendance.history(
            employee_id, start=start, end=end, limit=size + 1, offset=(page - 1) * size
        )
    except ValidationError as exc:
        flash(str(exc), "error")
        records = []

    # What can this employee do right now? Decided from their latest record.
    latest = services.attendance.history(employee_id, limit=1)
    if not employee.is_active:
        action = "inactive"
    elif latest and latest[0].is_open:
        action = "check_out"
    elif latest and latest[0].work_date == _today():
        action = "done"
    else:
        action = "check_in"

    filters = {k: v for k, v in (("from", start), ("to", end)) if v}
    return render_template(
        "employee_detail.html", employee=employee, records=records[:size],
        has_next=len(records) > size, page=page, filters=filters,
        date_from=start or "", date_to=end or "", action=action,
        latest=latest[0] if latest else None,
    )


@bp.route("/employees/<int:employee_id>/edit", methods=["GET", "POST"])
def employee_edit(employee_id: int):
    services = get_services()
    employee = services.employees.get(employee_id)
    errors: dict[str, str] = {}
    form = {f: str(getattr(employee, f) or "") for f in EMPLOYEE_FIELDS}
    if request.method == "POST":
        form = {f: request.form.get(f, "").strip() for f in EMPLOYEE_FIELDS}
        try:
            updated = services.employees.update(employee_id, **form)
            flash(f"{updated.full_name} was updated.", "success")
            return redirect(url_for("views.employee_detail", employee_id=employee_id))
        except AttendanceError as exc:
            errors = _field_errors(exc)
            flash(
                "Please correct the highlighted fields." if errors else str(exc), "error"
            )
    return render_template(
        "employee_form.html", employee=employee, form=form, errors=errors,
        departments=services.employees.departments(),
    )


@bp.post("/employees/<int:employee_id>/status")
def employee_status(employee_id: int):
    services = get_services()
    try:
        if request.form.get("status") == "active":
            employee = services.employees.activate(employee_id)
        else:
            employee = services.employees.deactivate(employee_id)
        flash(f"{employee.full_name} is now {employee.status}.", "success")
    except AttendanceError as exc:
        flash(str(exc), "error")
    return redirect(url_for("views.employee_detail", employee_id=employee_id))


@bp.post("/employees/<int:employee_id>/delete")
def employee_delete(employee_id: int):
    services = get_services()
    try:
        employee = services.employees.get(employee_id)
        removed = services.employees.delete(employee_id, force=request.form.get("force") == "on")
        flash(
            f"{employee.full_name} was deleted"
            + (f" along with {removed} attendance record(s)." if removed else "."),
            "success",
        )
        return redirect(url_for("views.employees"))
    except AttendanceError as exc:
        flash(str(exc), "error")
        return redirect(url_for("views.employee_detail", employee_id=employee_id))


# -- attendance records (corrections) ---------------------------------------------------
@bp.route("/records/<int:record_id>/edit", methods=["GET", "POST"])
def record_edit(record_id: int):
    services = get_services()
    record = services.attendance.get_record(record_id)
    employee = services.employees.get(record.employee_id)
    errors: dict[str, str] = {}
    fmt = "%Y-%m-%dT%H:%M"
    form = {
        "check_in": record.check_in.strftime(fmt),
        "check_out": record.check_out.strftime(fmt) if record.check_out else "",
        "notes": record.notes or "",
    }
    if request.method == "POST":
        form = {k: request.form.get(k, "").strip() for k in form}
        try:
            services.attendance.correct_record(
                record_id,
                check_in=form["check_in"] or None,
                check_out=form["check_out"] or None,
                notes=form["notes"],  # blank clears the note
            )
            flash("Attendance record updated; status recalculated.", "success")
            return redirect(url_for("views.employee_detail", employee_id=employee.id))
        except AttendanceError as exc:
            errors = exc.errors if isinstance(exc, ValidationError) else {}
            flash(str(exc), "error")
    return render_template(
        "record_edit.html", record=record, employee=employee, form=form, errors=errors
    )


@bp.post("/records/<int:record_id>/delete")
def record_delete(record_id: int):
    services = get_services()
    record = services.attendance.get_record(record_id)
    try:
        services.attendance.delete_record(record_id)
        flash(f"Attendance record for {record.work_date} was deleted.", "success")
    except AttendanceError as exc:
        flash(str(exc), "error")
    return redirect(url_for("views.employee_detail", employee_id=record.employee_id))


# -- reports --------------------------------------------------------------------------------
@bp.get("/daily")
def daily():
    services = get_services()
    raw = request.args.get("date") or ""
    try:
        entries = services.attendance.daily_report(raw or None)
        day = date.fromisoformat(raw) if raw else _today()
    except ValidationError as exc:
        flash(str(exc), "error")
        entries, day = services.attendance.daily_report(), _today()
    return render_template(
        "daily.html", entries=entries, day=day, counts=Counter(e.status for e in entries)
    )


@bp.get("/monthly")
def monthly():
    services = get_services()
    raw = request.args.get("month") or f"{_today():%Y-%m}"
    match = re.fullmatch(r"(\d{4})-(\d{2})", raw)
    employee_ref = request.args.get("employee") or None
    year, month = (int(match.group(1)), int(match.group(2))) if match else (_today().year, _today().month)
    try:
        if not match:
            raise ValidationError("month: use the YYYY-MM format")
        rows = services.attendance.monthly_summary(year, month, employee_ref)
    except AttendanceError as exc:
        flash(str(exc), "error")
        year, month, employee_ref = _today().year, _today().month, None
        rows = services.attendance.monthly_summary(year, month)
    return render_template(
        "monthly.html", rows=rows, month=f"{year}-{month:02d}",
        employee_ref=str(employee_ref or ""),
        employees=services.employees.list(limit=500),
        totals={
            "days": sum(r.days_worked for r in rows),
            "late": sum(r.days_late for r in rows),
            "half": sum(r.days_half_day for r in rows),
            "hours": round(sum(r.total_hours for r in rows), 2),
        },
    )
