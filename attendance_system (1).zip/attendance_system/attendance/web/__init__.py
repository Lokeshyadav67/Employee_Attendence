"""Flask web interface for the attendance system."""

from .app import create_web_app

__all__ = ["create_web_app"]
