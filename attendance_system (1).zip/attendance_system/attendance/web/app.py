"""Flask application factory."""

from __future__ import annotations

import hmac
import os
import secrets
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, Union

from flask import Flask, abort, current_app, g, render_template, request, session

from ..bootstrap import App, create_app
from ..config import default_db_path
from ..exceptions import AttendanceError, NotFoundError

CSRF_KEY = "_csrf"


def get_services() -> App:
    """Services bound to this request.

    SQLite connections may not be shared between threads, so every request
    opens its own (cheap) connection, closed again at teardown.
    """
    if "services" not in g:
        g.services = create_app(
            current_app.config["DB_PATH"], clock=current_app.config["CLOCK"]
        )
    return g.services


def csrf_token() -> str:
    if CSRF_KEY not in session:
        session[CSRF_KEY] = secrets.token_hex(16)
    return session[CSRF_KEY]


def create_web_app(
    db_path: Union[str, Path, None] = None,
    *,
    secret_key: Optional[str] = None,
    clock: Callable[[], datetime] = datetime.now,
    page_size: int = 15,
) -> Flask:
    app = Flask(__name__)
    app.config.update(
        # Without SECRET_KEY set, sessions (and flash messages) reset on restart.
        SECRET_KEY=secret_key or os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        DB_PATH=str(db_path if db_path is not None else default_db_path()),
        CLOCK=clock,
        PAGE_SIZE=page_size,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )

    # Open the database once at start-up so the schema is created/migrated early.
    create_app(app.config["DB_PATH"]).close()

    from .views import bp

    app.register_blueprint(bp)

    # -- CSRF protection for every state-changing request ------------------------
    @app.before_request
    def _check_csrf() -> None:
        expected = csrf_token()  # every session always has a token
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get(CSRF_KEY, "")
            if not hmac.compare_digest(sent, expected):
                abort(400, "Invalid or missing security token. Reload the page and try again.")

    @app.teardown_appcontext
    def _close_services(_exc: Optional[BaseException]) -> None:
        services = g.pop("services", None)
        if services is not None:
            services.close()

    @app.after_request
    def _security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        return response

    # -- template helpers ----------------------------------------------------------
    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["csrf_key"] = CSRF_KEY

    @app.template_filter("hm")
    def _hm(value: Optional[datetime]) -> str:
        return value.strftime("%H:%M") if value else "—"

    @app.template_filter("hrs")
    def _hrs(value: Optional[float]) -> str:
        return f"{value:.2f}" if value is not None else "—"

    @app.template_filter("label")
    def _label(value: str) -> str:
        return str(value).replace("_", " ")

    # -- error pages -----------------------------------------------------------------
    @app.errorhandler(NotFoundError)
    def _not_found(exc: NotFoundError):
        return render_template("error.html", code=404, message=str(exc)), 404

    @app.errorhandler(AttendanceError)
    def _bad_request(exc: AttendanceError):
        return render_template("error.html", code=400, message=str(exc)), 400

    @app.errorhandler(404)
    def _page_missing(_exc):
        return render_template("error.html", code=404, message="Page not found."), 404

    @app.errorhandler(400)
    def _bad_http_request(exc):
        return render_template("error.html", code=400, message=exc.description), 400

    return app
