"""Input validation and normalisation.

Validators never touch the database; they turn raw user input into clean,
typed values or raise ``ValidationError`` listing every problem found.
"""

from __future__ import annotations

import re
from datetime import date, datetime, time
from typing import Any, Mapping, Optional

from .exceptions import ValidationError

EMPLOYEE_CODE_RE = re.compile(r"^[A-Z][A-Z0-9-]{2,19}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?\d{7,15}$")

REQUIRED_FIELDS = (
    "employee_code",
    "first_name",
    "last_name",
    "email",
    "department",
    "designation",
    "hire_date",
)
OPTIONAL_FIELDS = ("phone",)

_DATETIME_FORMATS = (
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M",
)
_TIME_FORMATS = ("%H:%M:%S", "%H:%M")


# -- public parsers ----------------------------------------------------------
def parse_date(value: Any, field: str = "date") -> date:
    try:
        return _to_date(value)
    except ValueError:
        message = "must be a date in YYYY-MM-DD format"
        raise ValidationError(f"{field}: {message}", {field: message}) from None


def parse_datetime(
    value: Any, field: str = "datetime", default_date: Optional[date] = None
) -> datetime:
    """Accept a datetime, ``YYYY-MM-DD HH:MM[:SS]`` or (with ``default_date``) ``HH:MM``."""
    if isinstance(value, datetime):
        return value.replace(microsecond=0)
    if isinstance(value, str):
        text = value.strip()
        for fmt in _DATETIME_FORMATS:
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                pass
        if default_date is not None:
            for fmt in _TIME_FORMATS:
                try:
                    parsed = datetime.strptime(text, fmt).time()
                except ValueError:
                    continue
                return datetime.combine(default_date, parsed)
    expected = "YYYY-MM-DD HH:MM" + (" or HH:MM" if default_date else "")
    message = f"must be a date and time in {expected} format"
    raise ValidationError(f"{field}: {message}", {field: message})


def validate_pagination(limit: int, offset: int, max_limit: int = 500) -> None:
    errors = {}
    if not isinstance(limit, int) or not 1 <= limit <= max_limit:
        errors["limit"] = f"must be an integer between 1 and {max_limit}"
    if not isinstance(offset, int) or offset < 0:
        errors["offset"] = "must be a non-negative integer"
    if errors:
        raise ValidationError.from_errors(errors)


def validate_month(year: int, month: int) -> None:
    if not (isinstance(year, int) and 2000 <= year <= 2100):
        raise ValidationError("year: must be between 2000 and 2100", {"year": "invalid"})
    if not (isinstance(month, int) and 1 <= month <= 12):
        raise ValidationError("month: must be between 1 and 12", {"month": "invalid"})


# -- employee validation -----------------------------------------------------
def validate_employee(
    data: Mapping[str, Any], *, partial: bool = False, today: Optional[date] = None
) -> dict[str, Any]:
    """Validate and normalise employee fields.

    With ``partial=True`` only the supplied fields are checked (for updates).
    """
    today = today or date.today()
    allowed = set(REQUIRED_FIELDS) | set(OPTIONAL_FIELDS)
    errors: dict[str, str] = {}
    cleaned: dict[str, Any] = {}

    for field in data:
        if field not in allowed:
            errors[field] = "unknown field"

    cleaners = {
        "employee_code": _clean_code,
        "first_name": _clean_name,
        "last_name": _clean_name,
        "email": _clean_email,
        "phone": _clean_phone,
        "department": _clean_label,
        "designation": _clean_label,
        "hire_date": lambda v: _clean_hire_date(v, today),
    }

    for field in REQUIRED_FIELDS + OPTIONAL_FIELDS:
        if field not in data:
            if not partial and field in REQUIRED_FIELDS:
                errors[field] = "is required"
            continue
        try:
            cleaned[field] = cleaners[field](data[field])
        except ValueError as exc:
            errors[field] = str(exc)

    if errors:
        raise ValidationError.from_errors(errors)
    return cleaned


# -- field cleaners (raise ValueError with a human-readable message) ---------
def _text(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("is required" if value is None else "must be text")
    return " ".join(value.split())


def _clean_code(value: Any) -> str:
    code = _text(value).upper()
    if not EMPLOYEE_CODE_RE.match(code):
        raise ValueError(
            "must be 3-20 characters: start with a letter, then letters, digits or '-'"
        )
    return code


def _clean_name(value: Any) -> str:
    name = _text(value)
    if not 1 <= len(name) <= 50:
        raise ValueError("must be 1-50 characters")
    if not name[0].isalpha() or not all(c.isalpha() or c in " .'-" for c in name):
        raise ValueError("may contain only letters, spaces, apostrophes, hyphens and periods")
    return name


def _clean_email(value: Any) -> str:
    email = _text(value).lower()
    if len(email) > 254 or not EMAIL_RE.match(email):
        raise ValueError("is not a valid email address")
    return email


def _clean_phone(value: Any) -> Optional[str]:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    digits = re.sub(r"[\s().-]", "", _text(value))
    if not PHONE_RE.match(digits):
        raise ValueError("must contain 7-15 digits, optionally starting with '+'")
    return digits


def _clean_label(value: Any) -> str:
    label = _text(value)
    if not 2 <= len(label) <= 50:
        raise ValueError("must be 2-50 characters")
    return label


def _clean_hire_date(value: Any, today: date) -> date:
    parsed = _to_date(value)
    if parsed > today:
        raise ValueError("cannot be in the future")
    return parsed


def _to_date(value: Any) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return datetime.strptime(value.strip(), "%Y-%m-%d").date()
        except ValueError:
            pass
    raise ValueError("must be a date in YYYY-MM-DD format")
