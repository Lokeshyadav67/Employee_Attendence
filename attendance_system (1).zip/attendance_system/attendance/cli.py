"""Command-line interface (presentation layer only; no business logic)."""

from __future__ import annotations

import argparse
import logging
import re
import sys
from datetime import date, datetime
from typing import Optional, Sequence

from .bootstrap import App, create_app
from .config import DB_ENV_VAR, default_db_path
from .exceptions import AttendanceError, ValidationError
from .models import AttendanceRecord, Employee

SAMPLE_EMPLOYEES = [
    dict(employee_code="EMP001", first_name="Asha", last_name="Rao", email="asha.rao@example.com",
         phone="+919800000001", department="Engineering", designation="Software Engineer",
         hire_date="2023-01-16"),
    dict(employee_code="EMP002", first_name="Vikram", last_name="Singh", email="vikram.singh@example.com",
         phone="+919800000002", department="Engineering", designation="Tech Lead",
         hire_date="2021-06-01"),
    dict(employee_code="EMP003", first_name="Meera", last_name="Nair", email="meera.nair@example.com",
         department="Human Resources", designation="HR Manager", hire_date="2020-03-09"),
    dict(employee_code="EMP004", first_name="Rahul", last_name="Verma", email="rahul.verma@example.com",
         department="Finance", designation="Accountant", hire_date="2022-09-12"),
]


# -- output helpers ----------------------------------------------------------------
def render_table(headers: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    if not rows:
        return "No records found."
    text_rows = [[("-" if c is None else str(c)) for c in row] for row in rows]
    widths = [max(len(h), *(len(r[i]) for r in text_rows)) for i, h in enumerate(headers)]
    line = "  ".join("{:<%d}" % w for w in widths)
    out = [line.format(*headers), "  ".join("-" * w for w in widths)]
    out.extend(line.format(*r) for r in text_rows)
    return "\n".join(out)


def _hm(moment: Optional[datetime]) -> str:
    return moment.strftime("%H:%M") if moment else "-"


def _hours(value: Optional[float]) -> str:
    return f"{value:.2f}" if value is not None else "-"


def print_employee(e: Employee) -> None:
    fields = [
        ("ID", e.id), ("Code", e.employee_code), ("Name", e.full_name), ("Email", e.email),
        ("Phone", e.phone or "-"), ("Department", e.department),
        ("Designation", e.designation), ("Hire date", e.hire_date), ("Status", e.status),
        ("Created", e.created_at), ("Updated", e.updated_at),
    ]
    for label, value in fields:
        print(f"{label + ':':<13}{value}")


def print_record(r: AttendanceRecord, label: str = "") -> None:
    head = f"{label} " if label else ""
    print(
        f"{head}record #{r.id}: {r.work_date} in {_hm(r.check_in)} out {_hm(r.check_out)} "
        f"hours {_hours(r.worked_hours)} status {r.status}"
    )


def _month(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"(\d{4})-(\d{2})", value)
    if not match:
        raise argparse.ArgumentTypeError("use YYYY-MM, e.g. 2026-11")
    return int(match.group(1)), int(match.group(2))


# -- command handlers ----------------------------------------------------------------
def cmd_employee_add(app: App, a: argparse.Namespace) -> None:
    employee = app.employees.register(
        employee_code=a.code, first_name=a.first_name, last_name=a.last_name,
        email=a.email, phone=a.phone, department=a.department,
        designation=a.designation, hire_date=a.hire_date,
    )
    print(f"Registered {employee.full_name} ({employee.employee_code}, id {employee.id})")


def cmd_employee_list(app: App, a: argparse.Namespace) -> None:
    rows = app.employees.list(
        status=a.status, department=a.department, search=a.search, limit=a.limit, offset=a.offset
    )
    print(render_table(
        ["ID", "Code", "Name", "Department", "Designation", "Status"],
        [[e.id, e.employee_code, e.full_name, e.department, e.designation, e.status] for e in rows],
    ))


def cmd_employee_show(app: App, a: argparse.Namespace) -> None:
    print_employee(app.employees.get(a.ref))


def cmd_employee_update(app: App, a: argparse.Namespace) -> None:
    employee = app.employees.update(
        a.ref, first_name=a.first_name, last_name=a.last_name, email=a.email,
        phone=a.phone, department=a.department, designation=a.designation,
        hire_date=a.hire_date,
    )
    print(f"Updated {employee.full_name} ({employee.employee_code})")


def cmd_employee_deactivate(app: App, a: argparse.Namespace) -> None:
    e = app.employees.deactivate(a.ref)
    print(f"{e.full_name} ({e.employee_code}) is now inactive")


def cmd_employee_activate(app: App, a: argparse.Namespace) -> None:
    e = app.employees.activate(a.ref)
    print(f"{e.full_name} ({e.employee_code}) is now active")


def cmd_employee_delete(app: App, a: argparse.Namespace) -> None:
    removed = app.employees.delete(a.ref, force=a.force)
    print(f"Deleted employee {a.ref} (removed {removed} attendance record(s))")


def cmd_check_in(app: App, a: argparse.Namespace) -> None:
    print_record(app.attendance.check_in(a.ref, at=a.at, notes=a.notes), "Checked in:")


def cmd_check_out(app: App, a: argparse.Namespace) -> None:
    print_record(app.attendance.check_out(a.ref, at=a.at), "Checked out:")


def cmd_history(app: App, a: argparse.Namespace) -> None:
    employee = app.employees.get(a.ref)
    rows = app.attendance.history(
        a.ref, start=a.date_from, end=a.date_to, limit=a.limit, offset=a.offset
    )
    print(f"Attendance for {employee.full_name} ({employee.employee_code})")
    print(render_table(
        ["ID", "Date", "Check-in", "Check-out", "Hours", "Status", "Notes"],
        [[r.id, r.work_date, _hm(r.check_in), _hm(r.check_out), _hours(r.worked_hours),
          r.status, r.notes] for r in rows],
    ))


def cmd_daily(app: App, a: argparse.Namespace) -> None:
    entries = app.attendance.daily_report(a.date)
    print(f"Daily report for {a.date or date.today()}")
    print(render_table(
        ["Code", "Name", "Department", "Status", "Check-in", "Check-out"],
        [[e.employee_code, e.full_name, e.department, e.status, _hm(e.check_in),
          _hm(e.check_out)] for e in entries],
    ))


def cmd_summary(app: App, a: argparse.Namespace) -> None:
    year, month = a.month or (date.today().year, date.today().month)
    rows = app.attendance.monthly_summary(year, month, a.employee)
    print(f"Monthly summary for {year}-{month:02d}")
    print(render_table(
        ["Code", "Name", "Department", "Days", "Late", "Half-day", "Open", "Hours"],
        [[s.employee_code, s.full_name, s.department, s.days_worked, s.days_late,
          s.days_half_day, s.open_records, f"{s.total_hours:.2f}"] for s in rows],
    ))


def cmd_correct(app: App, a: argparse.Namespace) -> None:
    print_record(
        app.attendance.correct_record(
            a.record_id, check_in=a.check_in, check_out=a.check_out, notes=a.notes
        ),
        "Corrected:",
    )


def cmd_delete_record(app: App, a: argparse.Namespace) -> None:
    app.attendance.delete_record(a.record_id)
    print(f"Deleted attendance record #{a.record_id}")


def cmd_serve(app: App, a: argparse.Namespace) -> None:
    try:
        from .web import create_web_app
    except ModuleNotFoundError as exc:
        if exc.name != "flask":
            raise
        raise AttendanceError(
            "The web interface needs Flask. Install it with: pip install -r requirements.txt"
        ) from exc
    web = create_web_app(a.db, page_size=15)
    print(f"Attendance web UI running at http://{a.host}:{a.port}  (Ctrl+C to stop)")
    web.run(host=a.host, port=a.port, debug=a.debug)


def cmd_seed(app: App, a: argparse.Namespace) -> None:
    if app.employees.list(limit=1):
        raise ValidationError("Database already contains employees; refusing to seed")
    for data in SAMPLE_EMPLOYEES:
        app.employees.register(**data)
    print(f"Added {len(SAMPLE_EMPLOYEES)} sample employees")


# -- parser ----------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="attendance", description="Employee attendance management (SQLite)."
    )
    parser.add_argument("--db", help=f"database file (default: ${DB_ENV_VAR} or {default_db_path()})")
    parser.add_argument("-v", "--verbose", action="store_true", help="enable debug logging")
    top = parser.add_subparsers(dest="group", required=True)

    # employee ...
    emp = top.add_parser("employee", help="manage employees").add_subparsers(
        dest="command", required=True
    )
    p = emp.add_parser("add", help="register an employee")
    p.add_argument("--code", required=True, help="unique code, e.g. EMP001")
    p.add_argument("--first-name", required=True)
    p.add_argument("--last-name", required=True)
    p.add_argument("--email", required=True)
    p.add_argument("--phone")
    p.add_argument("--department", required=True)
    p.add_argument("--designation", required=True)
    p.add_argument("--hire-date", required=True, help="YYYY-MM-DD")
    p.set_defaults(func=cmd_employee_add)

    p = emp.add_parser("list", help="list employees")
    p.add_argument("--status", choices=["active", "inactive"])
    p.add_argument("--department")
    p.add_argument("--search", help="match name, code or email")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--offset", type=int, default=0)
    p.set_defaults(func=cmd_employee_list)

    p = emp.add_parser("show", help="show one employee")
    p.add_argument("ref", help="employee id or code")
    p.set_defaults(func=cmd_employee_show)

    p = emp.add_parser("update", help="update employee details")
    p.add_argument("ref", help="employee id or code")
    for flag in ("first-name", "last-name", "email", "phone", "department", "designation", "hire-date"):
        p.add_argument(f"--{flag}")
    p.set_defaults(func=cmd_employee_update)

    for name, func, text in (
        ("deactivate", cmd_employee_deactivate, "mark an employee inactive"),
        ("activate", cmd_employee_activate, "mark an employee active"),
    ):
        p = emp.add_parser(name, help=text)
        p.add_argument("ref", help="employee id or code")
        p.set_defaults(func=func)

    p = emp.add_parser("delete", help="permanently delete an employee")
    p.add_argument("ref", help="employee id or code")
    p.add_argument("--force", action="store_true", help="also delete attendance history")
    p.set_defaults(func=cmd_employee_delete)

    # attendance ...
    att = top.add_parser("attendance", help="record and query attendance").add_subparsers(
        dest="command", required=True
    )
    p = att.add_parser("check-in", help="record a check-in")
    p.add_argument("ref", help="employee id or code")
    p.add_argument("--at", help='"YYYY-MM-DD HH:MM" or "HH:MM" (default: now)')
    p.add_argument("--notes")
    p.set_defaults(func=cmd_check_in)

    p = att.add_parser("check-out", help="record a check-out")
    p.add_argument("ref", help="employee id or code")
    p.add_argument("--at", help='"YYYY-MM-DD HH:MM" or "HH:MM" (default: now)')
    p.set_defaults(func=cmd_check_out)

    p = att.add_parser("history", help="attendance history of an employee")
    p.add_argument("ref", help="employee id or code")
    p.add_argument("--from", dest="date_from", help="YYYY-MM-DD")
    p.add_argument("--to", dest="date_to", help="YYYY-MM-DD")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--offset", type=int, default=0)
    p.set_defaults(func=cmd_history)

    p = att.add_parser("daily", help="who is in/absent on a day")
    p.add_argument("--date", help="YYYY-MM-DD (default: today)")
    p.set_defaults(func=cmd_daily)

    p = att.add_parser("summary", help="monthly totals per employee")
    p.add_argument("--month", type=_month, help="YYYY-MM (default: current month)")
    p.add_argument("--employee", help="restrict to one employee id or code")
    p.set_defaults(func=cmd_summary)

    p = att.add_parser("correct", help="fix times or notes of a record")
    p.add_argument("record_id", type=int)
    p.add_argument("--check-in")
    p.add_argument("--check-out")
    p.add_argument("--notes")
    p.set_defaults(func=cmd_correct)

    p = att.add_parser("delete", help="delete an attendance record")
    p.add_argument("record_id", type=int)
    p.set_defaults(func=cmd_delete_record)

    # seed
    p = top.add_parser("seed", help="load sample employees into an empty database")
    p.set_defaults(func=cmd_seed)

    # serve
    p = top.add_parser("serve", help="start the web interface (requires Flask)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5000)
    p.add_argument("--debug", action="store_true", help="auto-reload (development only)")
    p.set_defaults(func=cmd_serve)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )
    app = create_app(args.db)
    try:
        args.func(app, args)
        return 0
    except AttendanceError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    finally:
        app.close()


if __name__ == "__main__":
    sys.exit(main())
