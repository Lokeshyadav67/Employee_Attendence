"""Data-access layer: all SQL lives here.

Repositories know about tables and rows, not business rules. Constraint
violations are translated into domain exceptions.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime
from typing import Any, Mapping, Optional

from .database import Database
from .exceptions import ConflictError, DatabaseError, DuplicateError, NotFoundError
from .models import AttendanceRecord, DailyEntry, Employee, MonthlySummary


def _to_db(value: Any) -> Any:
    """Convert Python values to their stored TEXT representation."""
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, date):
        return value.isoformat()
    return value


def _like(term: str) -> str:
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def _translate_integrity_error(exc: sqlite3.IntegrityError) -> Exception:
    message = str(exc)
    if "employees.employee_code" in message:
        return DuplicateError("An employee with this code already exists")
    if "employees.email" in message:
        return DuplicateError("An employee with this email already exists")
    if "attendance.employee_id" in message and "work_date" in message:
        return DuplicateError("Attendance is already recorded for this employee on that date")
    if "FOREIGN KEY" in message:
        return ConflictError("Record is referenced by other data")
    if "CHECK constraint" in message:
        return ConflictError(f"Data violates a database rule: {message}")
    return DatabaseError(message)


class EmployeeRepository:
    _COLUMNS = (
        "employee_code", "first_name", "last_name", "email", "phone",
        "department", "designation", "hire_date",
    )

    def __init__(self, db: Database):
        self._db = db

    def add(self, data: Mapping[str, Any]) -> Employee:
        values = [_to_db(data.get(column)) for column in self._COLUMNS]
        placeholders = ", ".join("?" for _ in self._COLUMNS)
        try:
            cursor = self._db.execute(
                f"INSERT INTO employees ({', '.join(self._COLUMNS)}) "
                f"VALUES ({placeholders})",
                values,
            )
        except sqlite3.IntegrityError as exc:
            raise _translate_integrity_error(exc) from exc
        return self._require(cursor.lastrowid)

    def get(self, employee_id: int) -> Optional[Employee]:
        row = self._db.query_one("SELECT * FROM employees WHERE id = ?", (employee_id,))
        return Employee.from_row(row) if row else None

    def get_by_code(self, code: str) -> Optional[Employee]:
        row = self._db.query_one(
            "SELECT * FROM employees WHERE employee_code = ?", (code,)
        )
        return Employee.from_row(row) if row else None

    def list(
        self,
        *,
        status: Optional[str] = None,
        department: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Employee]:
        sql = "SELECT * FROM employees"
        conditions: list[str] = []
        params: list[Any] = []
        if status:
            conditions.append("status = ?")
            params.append(status)
        if department:
            conditions.append("department = ? COLLATE NOCASE")
            params.append(department)
        if search:
            conditions.append(
                "(first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\' "
                "OR employee_code LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\')"
            )
            params.extend([_like(search)] * 4)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY employee_code LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        return [Employee.from_row(r) for r in self._db.query_all(sql, params)]

    def departments(self) -> list[str]:
        rows = self._db.query_all(
            "SELECT DISTINCT department FROM employees ORDER BY department COLLATE NOCASE"
        )
        return [r["department"] for r in rows]

    def update(self, employee_id: int, changes: Mapping[str, Any]) -> Employee:
        allowed = set(self._COLUMNS) | {"status"}
        unknown = set(changes) - allowed
        if unknown:  # defensive: column names are interpolated, so whitelist them
            raise DatabaseError(f"Cannot update columns: {sorted(unknown)}")
        if not changes:
            return self._require(employee_id)
        assignments = ", ".join(f"{column} = ?" for column in changes)
        params = [_to_db(v) for v in changes.values()] + [employee_id]
        try:
            cursor = self._db.execute(
                f"UPDATE employees SET {assignments} WHERE id = ?", params
            )
        except sqlite3.IntegrityError as exc:
            raise _translate_integrity_error(exc) from exc
        if cursor.rowcount == 0:
            raise NotFoundError(f"Employee {employee_id} not found")
        return self._require(employee_id)

    def delete(self, employee_id: int) -> None:
        try:
            cursor = self._db.execute("DELETE FROM employees WHERE id = ?", (employee_id,))
        except sqlite3.IntegrityError as exc:
            raise _translate_integrity_error(exc) from exc
        if cursor.rowcount == 0:
            raise NotFoundError(f"Employee {employee_id} not found")

    def _require(self, employee_id: Optional[int]) -> Employee:
        employee = self.get(employee_id) if employee_id is not None else None
        if employee is None:
            raise NotFoundError(f"Employee {employee_id} not found")
        return employee


class AttendanceRepository:
    def __init__(self, db: Database):
        self._db = db

    def create(
        self,
        employee_id: int,
        work_date: date,
        check_in: datetime,
        status: str,
        notes: Optional[str] = None,
        check_out: Optional[datetime] = None,
    ) -> AttendanceRecord:
        try:
            cursor = self._db.execute(
                "INSERT INTO attendance "
                "(employee_id, work_date, check_in, check_out, status, notes) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    employee_id,
                    _to_db(work_date),
                    _to_db(check_in),
                    _to_db(check_out),
                    status,
                    notes,
                ),
            )
        except sqlite3.IntegrityError as exc:
            raise _translate_integrity_error(exc) from exc
        return self._require(cursor.lastrowid)

    def get(self, record_id: int) -> Optional[AttendanceRecord]:
        row = self._db.query_one("SELECT * FROM attendance WHERE id = ?", (record_id,))
        return AttendanceRecord.from_row(row) if row else None

    def get_for_day(self, employee_id: int, work_date: date) -> Optional[AttendanceRecord]:
        row = self._db.query_one(
            "SELECT * FROM attendance WHERE employee_id = ? AND work_date = ?",
            (employee_id, _to_db(work_date)),
        )
        return AttendanceRecord.from_row(row) if row else None

    def get_open_record(self, employee_id: int) -> Optional[AttendanceRecord]:
        row = self._db.query_one(
            "SELECT * FROM attendance WHERE employee_id = ? AND check_out IS NULL "
            "ORDER BY check_in DESC LIMIT 1",
            (employee_id,),
        )
        return AttendanceRecord.from_row(row) if row else None

    def set_times(
        self,
        record_id: int,
        *,
        work_date: date,
        check_in: datetime,
        check_out: Optional[datetime],
        status: str,
        notes: Optional[str],
    ) -> AttendanceRecord:
        try:
            cursor = self._db.execute(
                "UPDATE attendance SET work_date = ?, check_in = ?, check_out = ?, "
                "status = ?, notes = ? WHERE id = ?",
                (
                    _to_db(work_date),
                    _to_db(check_in),
                    _to_db(check_out),
                    status,
                    notes,
                    record_id,
                ),
            )
        except sqlite3.IntegrityError as exc:
            raise _translate_integrity_error(exc) from exc
        if cursor.rowcount == 0:
            raise NotFoundError(f"Attendance record {record_id} not found")
        return self._require(record_id)

    def list(
        self,
        *,
        employee_id: Optional[int] = None,
        start: Optional[date] = None,
        end: Optional[date] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AttendanceRecord]:
        sql = "SELECT * FROM attendance"
        conditions: list[str] = []
        params: list[Any] = []
        if employee_id is not None:
            conditions.append("employee_id = ?")
            params.append(employee_id)
        if start is not None:
            conditions.append("work_date >= ?")
            params.append(_to_db(start))
        if end is not None:
            conditions.append("work_date <= ?")
            params.append(_to_db(end))
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY work_date DESC, check_in DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        return [AttendanceRecord.from_row(r) for r in self._db.query_all(sql, params)]

    def count_for_employee(self, employee_id: int) -> int:
        row = self._db.query_one(
            "SELECT COUNT(*) AS n FROM attendance WHERE employee_id = ?", (employee_id,)
        )
        return row["n"]

    def delete(self, record_id: int) -> None:
        cursor = self._db.execute("DELETE FROM attendance WHERE id = ?", (record_id,))
        if cursor.rowcount == 0:
            raise NotFoundError(f"Attendance record {record_id} not found")

    def delete_for_employee(self, employee_id: int) -> int:
        cursor = self._db.execute(
            "DELETE FROM attendance WHERE employee_id = ?", (employee_id,)
        )
        return cursor.rowcount

    # -- reporting queries ---------------------------------------------------
    def daily_report(self, work_date: date) -> list[DailyEntry]:
        rows = self._db.query_all(
            "SELECT e.id AS employee_id, e.employee_code, "
            "       e.first_name || ' ' || e.last_name AS full_name, e.department, "
            "       a.check_in, a.check_out, a.status "
            "FROM employees e "
            "LEFT JOIN attendance a ON a.employee_id = e.id AND a.work_date = ? "
            "WHERE e.status = 'active' "
            "ORDER BY e.employee_code",
            (_to_db(work_date),),
        )
        return [DailyEntry.from_row(r) for r in rows]

    def monthly_summary(
        self, start: date, end: date, employee_id: Optional[int] = None
    ) -> list[MonthlySummary]:
        sql = (
            "SELECT e.id, e.employee_code, "
            "       e.first_name || ' ' || e.last_name AS full_name, e.department, "
            "       COUNT(a.id) AS days_worked, "
            "       COALESCE(SUM(a.status = 'late'), 0) AS days_late, "
            "       COALESCE(SUM(a.status = 'half_day'), 0) AS days_half_day, "
            "       COALESCE(SUM(a.id IS NOT NULL AND a.check_out IS NULL), 0) AS open_records, "
            "       COALESCE(SUM(CASE WHEN a.check_out IS NOT NULL "
            "           THEN (julianday(a.check_out) - julianday(a.check_in)) * 24 END), 0.0) "
            "           AS total_hours "
            "FROM employees e "
            "LEFT JOIN attendance a ON a.employee_id = e.id "
            "     AND a.work_date BETWEEN ? AND ? "
        )
        params: list[Any] = [_to_db(start), _to_db(end)]
        if employee_id is not None:
            sql += "WHERE e.id = ? "
            params.append(employee_id)
        else:
            sql += "WHERE e.status = 'active' "
        sql += "GROUP BY e.id ORDER BY e.employee_code"
        return [MonthlySummary.from_row(r) for r in self._db.query_all(sql, params)]

    def _require(self, record_id: Optional[int]) -> AttendanceRecord:
        record = self.get(record_id) if record_id is not None else None
        if record is None:
            raise NotFoundError(f"Attendance record {record_id} not found")
        return record
