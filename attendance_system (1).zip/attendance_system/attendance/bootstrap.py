"""Composition root: wires database, repositories and services together."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, Union

from .config import AttendancePolicy, default_db_path
from .database import Database
from .repositories import AttendanceRepository, EmployeeRepository
from .services import AttendanceService, EmployeeService


@dataclass
class App:
    db: Database
    employees: EmployeeService
    attendance: AttendanceService

    def close(self) -> None:
        self.db.close()


def create_app(
    db_path: Union[str, Path, None] = None,
    *,
    policy: Optional[AttendancePolicy] = None,
    clock: Callable[[], datetime] = datetime.now,
) -> App:
    db = Database(db_path if db_path is not None else default_db_path())
    employee_repo = EmployeeRepository(db)
    attendance_repo = AttendanceRepository(db)
    employees = EmployeeService(db, employee_repo, attendance_repo, clock=clock)
    attendance = AttendanceService(
        db, employees, attendance_repo, policy=policy or AttendancePolicy(), clock=clock
    )
    return App(db=db, employees=employees, attendance=attendance)
